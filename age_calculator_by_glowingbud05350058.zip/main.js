document.addEventListener('DOMContentLoaded', () => {
  // Set max date to today
  const today = new Date();
  const dateInput = document.getElementById('birthdate');
  dateInput.max = today.toISOString().split('T')[0];

  // Calculate age function
  function calculateAge(birthDate) {
    const today = new Date();
    const birth = new Date(birthDate);
    
    let years = today.getFullYear() - birth.getFullYear();
    let months = today.getMonth() - birth.getMonth();
    let days = today.getDate() - birth.getDate();

    // Adjust for negative months or days
    if (days < 0) {
      months--;
      const lastMonth = new Date(today.getFullYear(), today.getMonth() - 1, birth.getDate());
      days = Math.floor((today - lastMonth) / (1000 * 60 * 60 * 24));
    }
    
    if (months < 0) {
      years--;
      months += 12;
    }

    return { years, months, days };
  }

  function checkIfBirthday(birthDate) {
    const today = new Date();
    const birth = new Date(birthDate);
    return today.getMonth() === birth.getMonth() && today.getDate() === birth.getDate();
  }

  function createConfetti() {
    const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff'];
    const confettiCount = 100;
    const container = document.createElement('div');
    container.className = 'birthday-animation show';
    
    // Add birthday text
    const text = document.createElement('div');
    text.className = 'birthday-text';
    text.textContent = '🎉 Happy Birthday! 🎉';
    container.appendChild(text);

    // Add confetti pieces
    for (let i = 0; i < confettiCount; i++) {
      const confetti = document.createElement('div');
      confetti.className = 'confetti';
      confetti.style.left = Math.random() * 100 + 'vw';
      confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
      confetti.style.animationDuration = (Math.random() * 3 + 2) + 's';
      confetti.style.animationDelay = (Math.random() * 2) + 's';
      container.appendChild(confetti);
    }

    document.body.appendChild(container);

    // Remove animation after it's complete
    setTimeout(() => {
      container.remove();
    }, 5000);
  }

  function getNextBirthday(birthDate) {
    const today = new Date();
    const birth = new Date(birthDate);
    let nextBirthday = new Date(today.getFullYear(), birth.getMonth(), birth.getDate());
    
    if (nextBirthday < today) {
      nextBirthday = new Date(today.getFullYear() + 1, birth.getMonth(), birth.getDate());
    }
    
    return nextBirthday;
  }

  function updateCountdown(birthdate) {
    const nextBirthday = getNextBirthday(birthdate);
    const now = new Date();
    const difference = nextBirthday - now;

    if (difference < 0) return;

    const days = Math.floor(difference / (1000 * 60 * 60 * 24));
    const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((difference % (1000 * 60)) / 1000);

    document.getElementById('countdown-days').textContent = days;
    document.getElementById('countdown-hours').textContent = hours;
    document.getElementById('countdown-minutes').textContent = minutes;
    document.getElementById('countdown-seconds').textContent = seconds;

    const nextDate = nextBirthday.toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    });
    document.getElementById('next-birthday-date').textContent = nextDate;
  }

  // Update UI
  function updateResult(age) {
    document.getElementById('years').textContent = age.years;
    document.getElementById('months').textContent = age.months;
    document.getElementById('days').textContent = age.days;
  }

  // Event listener for calculate button
  document.getElementById('calculate').addEventListener('click', () => {
    const birthdate = dateInput.value;
    
    if (!birthdate) {
      alert('Please enter your birthdate');
      return;
    }

    const age = calculateAge(birthdate);
    updateResult(age);

    // Check if it's the user's birthday
    if (checkIfBirthday(birthdate)) {
      createConfetti();
    }

    // Start countdown
    updateCountdown(birthdate);
    // Update countdown every second
    clearInterval(window.countdownInterval);
    window.countdownInterval = setInterval(() => {
      updateCountdown(birthdate);
      // Check for birthday during countdown updates
      if (checkIfBirthday(birthdate)) {
        createConfetti();
      }
    }, 1000);

    // Add animation
    const numbers = document.querySelectorAll('.number, .countdown-number');
    numbers.forEach(number => {
      number.style.animation = 'none';
      number.offsetHeight; // Trigger reflow
      number.style.animation = 'popIn 0.5s ease-out';
    });
  });

  // Add animation keyframes dynamically
  const style = document.createElement('style');
  style.textContent = `
    @keyframes popIn {
      0% { transform: scale(0.8); opacity: 0; }
      100% { transform: scale(1); opacity: 1; }
    }
  `;
  document.head.appendChild(style);
});